
This is libusb-win32 (https://github.com/mcuee/libusb-win32) version 1.4.0.0. 
Libusb-win32 is a library that allows userspace application to access USB 
devices on Windows operation systems (Win7,Win8,Win10,Win11). 
It is derived from and fully API compatible to libusb available at 
http://libusb.sourceforge.net.

For more information visit the project's web site at:

https://github.com/mcuee/libusb-win32

